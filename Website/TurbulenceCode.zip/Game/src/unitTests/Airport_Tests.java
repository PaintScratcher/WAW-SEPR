package unitTests;

public class Airport_Tests {
	
	// Airport class currently doesn't hold testable behaviour
	
}
