
public class Tests {

	
	public static void main(String[] args) {
		// POINTS
		
		
		
		// WAYPOINT
		
		
		
		// ENTRYPOINT
		
		
		
		// EXITPOINT
		
		
		
		// FLIGHT
		
		
		
		//FLIGHTPLAN
		
		
		
		//AIRSPACE
		
		
		
		//SEPARATION RULES
		
		

	}

}
